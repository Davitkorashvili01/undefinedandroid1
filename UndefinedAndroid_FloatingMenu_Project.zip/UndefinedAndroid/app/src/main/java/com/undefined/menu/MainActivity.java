package com.undefined.menu;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 771;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9,7,14));
        getWindow().setNavigationBarColor(Color.rgb(9,7,14));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(13,10,20));
        Button overlay = new Button(this);
        overlay.setText("SHOW FLOATING MENU");
        overlay.setTextColor(Color.WHITE);
        overlay.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(125,45,220)));
        overlay.setOnClickListener(v -> enableOverlay());
        root.addView(overlay, new LinearLayout.LayoutParams(-1, 54));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(13,10,20));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        web.loadUrl("file:///android_asset/index.html");
    }
    private void enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, OVERLAY_REQUEST);
        } else startOverlay();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST) {
            if (Settings.canDrawOverlays(this)) startOverlay();
            else Toast.makeText(this, "Overlay permission is needed to show the floating demo menu", Toast.LENGTH_LONG).show();
        }
    }
    private void startOverlay() {
        startService(new Intent(this, FloatingMenuService.class));
        Toast.makeText(this, "Floating demo menu enabled", Toast.LENGTH_SHORT).show();
    }
}
