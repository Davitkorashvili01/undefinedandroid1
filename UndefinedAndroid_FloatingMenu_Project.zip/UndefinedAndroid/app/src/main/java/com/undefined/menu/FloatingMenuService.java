package com.undefined.menu;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;

public class FloatingMenuService extends Service {
    private WindowManager wm; private View bubble, panel; private WindowManager.LayoutParams bubbleParams, panelParams;
    private int purple = Color.rgb(155, 55, 255);
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() { super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showBubble(); }
    private WindowManager.LayoutParams params(int w,int h,int gravity) {
        return new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    }
    private TextView text(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(18,12,18,12); return t; }
    private void showBubble() {
        TextView b=text("UF",16); b.setGravity(Gravity.CENTER); b.setBackgroundColor(purple); bubble=b;
        bubbleParams=params(62,62,Gravity.TOP|Gravity.START); bubbleParams.x=12; bubbleParams.y=240;
        b.setOnClickListener(v -> togglePanel());
        b.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;boolean moved;
          public boolean onTouch(View v, MotionEvent e){ if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=bubbleParams.x;oy=bubbleParams.y;moved=false;return true;} if(e.getAction()==MotionEvent.ACTION_MOVE){int dx=(int)(e.getRawX()-sx),dy=(int)(e.getRawY()-sy);if(Math.abs(dx)>8||Math.abs(dy)>8)moved=true;bubbleParams.x=ox+dx;bubbleParams.y=oy+dy;wm.updateViewLayout(bubble,bubbleParams);return true;} if(e.getAction()==MotionEvent.ACTION_UP){if(!moved)togglePanel();return true;}return false;}});
        wm.addView(bubble,bubbleParams);
    }
    private void togglePanel(){ if(panel!=null){wm.removeView(panel);panel=null;return;} 
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(12,8,12,8); box.setBackgroundColor(Color.rgb(18,12,32));
        TextView title=text("undefined · COUNTER FLAME   ×",15); title.setBackgroundColor(purple); title.setOnClickListener(v->{if(panel!=null){wm.removeView(panel);panel=null;}}); box.addView(title);
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        String[] labels={"Demo option 1","Demo option 2","Demo option 3","Demo option 4","Demo option 5"};
        for(String label:labels){ final boolean[] on={false}; TextView item=text(label+"     OFF",14);item.setBackgroundColor(Color.rgb(35,25,55));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=6;list.addView(item,lp);item.setOnClickListener(v->{on[0]=!on[0];item.setText(label+(on[0]?"     ON":"     OFF"));item.setBackgroundColor(on[0]?purple:Color.rgb(35,25,55));});}
        scroll.addView(list);box.addView(scroll); panel=box;
        panelParams=params(285,WindowManager.LayoutParams.WRAP_CONTENT,Gravity.TOP|Gravity.START);panelParams.x=85;panelParams.y=220;wm.addView(panel,panelParams);
    }
    @Override public void onDestroy(){super.onDestroy();if(panel!=null)wm.removeView(panel);if(bubble!=null)wm.removeView(bubble);}
}
