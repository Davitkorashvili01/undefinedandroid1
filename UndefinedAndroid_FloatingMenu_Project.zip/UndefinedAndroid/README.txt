UNDEFINED Android UI prototype
================================

This is an Android Studio project source, not a precompiled APK.
It recreates the purple mobile menu shown in the supplied screenshot.
The switches are visual-only and do not connect to Counter Flame or provide real ESP.

Build APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync/download Android Gradle Plugin and Android SDK (compile SDK 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

The app itself needs no special permissions or internet access.
